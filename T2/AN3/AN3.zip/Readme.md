--------ANALISIS--------

OBJETO: entidad existente en la memoria del ordenador que tiene unas propiedades (atributos o datos sobre sí mismo almacenados por el objeto) y unas operaciones disponibles específicas (métodos).

CLASES: Las clases son la base de la Programación Orientada a Objetos. Una clase es una plantilla que define la forma de un objeto; en ella se agrupan datos y métodos que operarán sobre esos datos.

INSTANCIAS: una referencia de una clase hacia otra con lo cual permite a ambas clases ínteractuar entre si

HTML: HTML, siglas en inglés de HyperText Markup Language (‘lenguaje de marcado de hipertexto’), hace referencia al lenguaje de marcado para la elaboración de páginas web. Es un estándar que sirve de referencia del software que conecta con la elaboración de páginas web en sus diferentes versiones, define una estructura básica y un código (denominado código HTML) para la definición de contenido de una página web, como texto, imágenes, videos, juegos, entre otros.

ANGULAR: Angular es un framework para aplicaciones web desarrollado en TypeScript, de código abierto, mantenido por Google, que se utiliza para crear y mantener aplicaciones web de una sola página.

MODULOS: Son contenedores para las diferentes partes de una aplicación. Los módulos permiten a angular saber las importaciones y exportaciones necesarias para que cierto componente funcione.

NGIF: es un condicionante que si se cumple se agregan a la pagina HTML.

NGFOR: es una directiva que nos permite generar muchos elementos HTML repetirdos a partir del recorrido de un arreglo de datos.

------Prueba------
He estado intentando que se visualice al poner ng serve pero no encuentro la solucion de porque no se ve.
<img src="captura.PNG" alt="prueba">


