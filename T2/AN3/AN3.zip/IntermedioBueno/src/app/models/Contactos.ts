export class Contactos {
    public nombre: String;
    public imagen: String;

    constructor(nombre: String, imagen: String) {
        this.nombre = nombre;
        this.imagen = imagen;
    }

}