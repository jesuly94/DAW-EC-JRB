import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rellena-datos',
  templateUrl: './rellena-datos.component.html',
  styleUrls: ['./rellena-datos.component.css']
})
export class RellenaDatosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
