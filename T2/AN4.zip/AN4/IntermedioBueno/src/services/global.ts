export var Global = {
    url: 'https://pokeapi.co/api/v2/'
}