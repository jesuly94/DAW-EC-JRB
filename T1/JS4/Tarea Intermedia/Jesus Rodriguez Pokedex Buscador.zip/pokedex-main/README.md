# Pokedex
Pokedex creada con pokeapi

<img src="https://i.ibb.co/ygyy0jz/Screen-Shot-2021-06-04-at-20-06-58.png" alt="poke" border="0"  width="400" />

**App desarrollada en este tutorial:** https://youtu.be/i8Zfq87HoGg

Tecnologías:
- HTML
- CSS
- JavaScript
